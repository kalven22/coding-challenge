import main
import unittest


class TestMainApplication(unittest.TestCase):

    # Tests search_phrase_filter function
    def test_search_phrase_filter(self):
        self.assertEqual(main.search_phrase_filter([
            {'ID State': '04000US54', 'State': 'West Virginia', 'ID Year': 2015,
             'Year': '2015', 'Population': 1844128},
            {'ID State': '04000US55', 'State': 'Michigan', 'ID Year': 2015,
             'Year': '2015', 'Population': 9922576},
            {'ID State': '04000US56', 'State': 'Minnesota', 'ID Year': 2015,
             'Year': '2015', 'Population': 5489594},
            {'ID State': '04000US72', 'State': 'Puerto Rico', 'ID Year': 2015,
             'Year': '2015', 'Population': 3474182}]
            , 'mi'),
            {'Michigan': 9922576, 'Minnesota': 5489594})

    # Tests sort_function based on the sort_type provided ASC or DESC
    def test_sort_function(self):
        self.assertEqual(main.sort_function({'Washington': 7614893, 'Wyoming': 578759}
                                            , 'ASC'), [('Wyoming', 578759), ('Washington', 7614893)])
        self.assertEqual(main.sort_function({'New York': 12345, 'Florida': 123456, 'Texas': 1234567}
                                            , 'DESC'), [('Texas', 1234567), ('Florida', 123456), ('New York', 12345)])

    # Tests input_validation function
    def test_input_validation(self):
        self.assertEqual(main.input_validation('201', 'new', 'ASC'), (False, 'Search year length must be 4-digits. '
                                                                             'Example: 2015'))
        self.assertEqual(main.input_validation('2017', 'ing', 'ASC'), (True, 'None'))
        self.assertEqual(main.input_validation('', 'ing', 'DESC'),
                         (False, 'Search year length must be 4-digits. Example: 2015'))
        self.assertEqual(main.input_validation('2014', 'ing', 'ddd'),
                         (False, 'Output option can either be ASC or DESC'))
        self.assertEqual(main.input_validation('2018', '', 'ddd'),
                         (False, 'Phrase cannot be empty or numeric. Example: new'))


if __name__ == '__main__':
    unittest.main()
