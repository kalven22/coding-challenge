import sys
import requests


# Prompts user inputs
# Return list of input values
def user_inputs():
    search_year = input('Enter year in format yyyy: ').strip()
    phrase = input('Enter search phrase, like New: ').strip().lower()
    sort_order = input('Enter sort type either ASC or DESC: ').strip().upper()
    return [search_year, phrase, sort_order]


# Checks user inputs, and returns (True, 'None') if input is valid
# Else, returns (False, 'Error Message')
def input_validation(search_year, phrase, sort_order):
    status = False
    error_message = 'None'
    if len(search_year) != 4:
        error_message = 'Search year length must be 4-digits. Example: 2015'
    elif not phrase or phrase.isnumeric():
        error_message = 'Phrase cannot be empty or numeric. Example: new'
    elif sort_order != 'ASC' and sort_order != 'DESC':
        error_message = 'Output option can either be ASC or DESC'
    else:
        status = True
    return status, error_message


# Sends HTTP GET request to DataUSA API,
# Parses the HTTP Response, and
# Returns list of objects
def send_http_request(year):
    base_url = 'https://datausa.io/api/data?drilldowns=State&measures=Population&year='
    url = base_url + year
    result = requests.get(url).json()
    return result['data']


# Filters response data using search phrase
# Returns dictionary containing filtered objects
def search_phrase_filter(http_response_data, phrase):
    filtered_data = {}
    for obj in http_response_data:
        state = obj['State']
        if state is not None and phrase.lower() in state.lower():
            filtered_data[state] = obj['Population']
    return filtered_data


# Sorts the results in ascending or descending order based on Population
# Returns sorted list of tuples
def sort_function(result_states, sort_type):
    if sort_type == 'ASC':
        sorted_states = sorted(result_states.items(), key=lambda x: x[1])
    else:
        sorted_states = sorted(result_states.items(), key=lambda x: x[1], reverse=True)
    return sorted_states


# Prints the results to the console
def pretty_print(sorted_result):
    header_state, header_population = 'State', 'Population'
    print(f'\n{header_state:15} ==> {header_population:10}')
    print('---------------------------------')
    for key, value in sorted_result:
        print(f'{key:15} ==> {value:10d}')


if __name__ == '__main__':

    if len(sys.argv) == 1:
        year, phrase, sort_order = user_inputs()
    elif len(sys.argv) != 4:
        print('Error: Not enough args provided. Try again!')
        sys.exit(1)
    else:
        year = sys.argv[1].strip()
        phrase = sys.argv[2].strip().lower()
        sort_order = sys.argv[3].strip().upper()

    input_valid_status, input_valid_message = input_validation(year, phrase, sort_order)

    if input_valid_status:
        http_response_data = send_http_request(year)
        result = search_phrase_filter(http_response_data, phrase)
        sorted_result = sort_function(result, sort_order)
        pretty_print(sorted_result)
    else:
        print(input_valid_message)
        print('Exiting..Try again!')
        sys.exit(1)
